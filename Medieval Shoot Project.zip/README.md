# Spark AR Bowling

### Getting Started
run ``` npm i ```
run ``` npm run build ```

